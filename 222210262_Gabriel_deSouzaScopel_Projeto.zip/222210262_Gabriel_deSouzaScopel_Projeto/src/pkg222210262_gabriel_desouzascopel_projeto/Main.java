/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg222210262_gabriel_desouzascopel_projeto;

import pkg222210262_gabriel_desouzascopel_projeto.view.FrmUsuario;


/**
 *
 * @author Gabriel Scopel
 * @classe main
 * @version 1.0
 * @see FrmUsuario
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      //instanciando um novo objeto da classe FrmUsuario 
      FrmUsuario frm = new FrmUsuario();
      //setando visibilidade true no objeto criado
      frm.setVisible(true);
    }
    
}
