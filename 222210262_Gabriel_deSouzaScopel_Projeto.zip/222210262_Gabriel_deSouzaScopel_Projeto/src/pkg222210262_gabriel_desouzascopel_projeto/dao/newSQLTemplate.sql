/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/SQLTemplate.sql to edit this template
 */
/**
 * Author:  Gabriel Scopel
 * Created: 23 de nov. de 2022
 */

create table projeto (
en double precision not null,
en2 double precision not null,
energia double precision not null,
freq text not null,
lamb text not null,
vi text not null,
compi text not null,
vf text not null,
compf text not null,
funci text not null,
pi text not null,
funcf text not null,
pf text not null
);
